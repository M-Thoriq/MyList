package com.thoriq.mylist

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.thoriq.mylist.databinding.ItemLayoutBinding

/**
 * [RecyclerView.Adapter] that can display a [PlaceholderItem].
 * TODO: Replace the implementation with code for your data type.
 */
data class Quote(
    val quote: String,
    val author: String
)

class ItemAdapter(
    private val values: List<Quote>,
) : RecyclerView.Adapter<ItemAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemLayoutBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = values[position]
        val stringQuote = "\"${item.quote}\" -${item.author}"
        holder.binding.itemNumber.text = (position+1).toString()
        holder.binding.content.text = stringQuote
    }

    override fun getItemCount(): Int = values.size

    inner class ViewHolder(val binding: ItemLayoutBinding) : RecyclerView.ViewHolder(binding.root)

}